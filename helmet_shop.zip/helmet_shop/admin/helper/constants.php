<?php
include_once($_SERVER["DOCUMENT_ROOT"].'\helmet_shop\helper\constants.php');
date_default_timezone_set("Asia/Bangkok");
define("ADMIN_URL", APP_URL."admin/");
define("DELIMITER", "#");
define("EXCEL_HEADING_1_SIZE", "18");
define("EXCEL_HEADING_2_SIZE", "15");
define("EXCEL_HEADING_3_SIZE", "12");
define("IMPORT_INTEREST", 0.4);
define("EXCEL_FONT", "Times New Roman");

define("WRONG_FILE_STRUCTURE", "Cấu trúc tập tin không hợp lệ!");
?>